 
#' @rdname dispersions2
#' @export
setGeneric("dispersionMatrix", function(object,...) standardGeneric("dispersionMatrix"))

#' @rdname dispersions2
#' @export
setGeneric("dispersionMatrix<-", function(object,...,value) standardGeneric("dispersionMatrix<-"))
